package ui;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Scanner;
import model.Controller;
import java.util.GregorianCalendar;

public class Executable {

	private Scanner reader;
	private Controller rXSystem;

	public Executable() {

		reader = new Scanner(System.in);
		rXSystem = new Controller();
	}

	public static void main(String[] args) {

		Executable ejecutable = new Executable();
		ejecutable.menu();

	}

	private void menu() {

		System.out.println("Bienvenido a ReaderX!");
		boolean flag = false;

		while (!flag) {

			System.out.println("\nMENU PRINCIPAL");
			System.out.println("\n1. Registrar usuario");
			System.out.println("2. Registrar un producto bibliografico");
			System.out.println("3. Modificar Producto");
			System.out.println("4. Borrar Producto");
			System.out.println("5. Vender Libro");
			System.out.println("6. Suscribirse a Revista");
			System.out.println("7. Desuscribirse a Revista");
			System.out.println("8. Simulación de Lectura");
			System.out.println("9. Presentar Biblioteca");
			System.out.println("10. Generacion de Informes");
			System.out.println("0. Salir");
			int option = reader.nextInt();

			switch (option) {

			case 1:
				registerUser();
				break;
			case 2:
				registerBook();
				break;
			case 3:
				modifyProduct();
				break;
			case 4:
				deleteProduct();
				break;
			case 5:
				sellBook();
				break;
			case 6:
				subscribeMagazine();
				break;
			case 7:
				unsubscribeMagazine();
				break;
			case 8:
				simulateLecture();
				break;
			case 9:
				showMatrix();
				break;
			case 10:
				System.out.println("1. Acumulado total de páginas leidas por tipo de producto");
				System.out.println("2. Género y categoría más leida");
				System.out.println("3. Top 5 libros y revistas más leidas");
				System.out.println("4. Número de libros vendidos y valor total de ventas por genero");
				System.out.println("5. Número de suscripciones activas y valor total de suscripciones por categoria");
				
				int option1 = reader.nextInt();

				switch(option1){

				case 1:
					totalPages();
					break;
				case 2: 
					genCatMRead();
					break;
				case 3:
					topRead();
					break;
				case 4:
					bookSales();
					break;
				case 5:
					magazineSuscriptions();
					break;

				}

				break;
			case 0:
				flag = true;
				break;
			default:
				System.out.println("Opcion invalida");
				break;

			}

		}

	}

	private void registerUser() {

		System.out.println("Digite a continuacion la informacion de un nuevo usuario");

		// Limpieza de buffer
		reader.nextLine();

		System.out.println("Digite la cedula");
		String id = reader.nextLine();

		System.out.println("Digite el nombre");
		String name = reader.nextLine();

		System.out.println("Digite el nickname");
		String nickname = reader.nextLine();

		System.out.println("Digite el tipo de usuario que desea crear \n1) Regular \n2) Premium");
		int option = reader.nextInt();


		System.out.println(rXSystem.registerUser(id, name, nickname, option)); 

			
	}



	public void registerBook() {



		System.out.println("Digite a continuacion la informacion de un nuevo producto bibliografico");

		System.out.println("Digite que tipo de producto desea registrar \n1)Libro \n2)Revista");
		int optionP = reader.nextInt();

		boolean valido = false;

		String id = "";
		String name = "";
		int numPages = 0;
		String review = "";
		int genre = 0;
		String url = "";
		double price = 0;
		int category = 0;
		String peridiocity = "";
		int subscriptions = 0;
		int ventas = 0;

		if(optionP == 1){

			// Limpieza de buffer
			reader.nextLine();

			while (valido == false){

				System.out.println("Digite el identificador. Ej.: A1F (Recuerde usar caracteres hexadecimales)");
				id = reader.nextLine();

				if(valido = rXSystem.validaIdentificador(id)){
					System.out.println("Id valido");
				} else {
					System.out.println("Id ingresado no cumple lo necesitado");
				}

			}

			System.out.println("Digite el nombre");
			name = reader.nextLine();

			System.out.println("Digite el numero de paginas del libro");
			numPages = reader.nextInt();

			// Limpieza de buffer
			reader.nextLine();

			System.out.println("Digite una reseña corta del libro");
			review = reader.nextLine();

			System.out.println("Digite el URL que lleva a la portada del libro");
			url = reader.nextLine();

			System.out.println("Digite el tipo de genero. \n1. Ciencia Ficcion \n2. Fantasia \n3. Novela historica");
			genre = reader.nextInt();

			System.out.println("Digite el valor de venta");
			price = reader.nextDouble();

			System.out.println("Digite el numero de ejemplares vendidos");
			ventas = reader.nextInt();

		}

		if(optionP == 2){

			// Limpieza de buffer
			reader.nextLine();

			while (valido == false){

				System.out.println("Digite el identificador. Ej.: A1F (Recuerde usar caracteres alfanumericos)");
				id = reader.nextLine();

				if(valido = rXSystem.validaIdentificador2(id)){
					System.out.println("Id valido");
				} else {
					System.out.println("Id ingresado no cumple lo necesitado");
				}

			}


			System.out.println("Digite el nombre");
			name = reader.nextLine();

			System.out.println("Digite el numero de paginas del producto");
			numPages = reader.nextInt();

			System.out.println("Digite la categoria de la revista \n1)Variedades \n2)Diseño  \n3)Científica ");
			category = reader.nextInt();
			
			// Limpieza de buffer
			reader.nextLine();

			System.out.println("Digite el URL que lleva a la portada de la revista");
			url = reader.nextLine();

			System.out.println("Digite el valor de suscripcion");
			price = reader.nextDouble();

			// Limpieza de buffer
			reader.nextLine();

			System.out.println("Digite la periodicidad de emision");
			peridiocity = reader.nextLine();

			System.out.println("Digite el numero de suscripciones activas");
			subscriptions = reader.nextInt();

		}

		System.out.println("Digite el numero de paginas leidas");
		double readPages  = reader.nextInt();

		System.out.println("Por favor digita la fecha de publicación en dias, meses y año");

		System.out.println("Digite el dia de publicacion");
		int diaInicio = reader.nextInt();

		System.out.println("Digite el mes de publicacion");
		int mesInicio = reader.nextInt();

		System.out.println("Digite el año de publicacion");
		int anInicio = reader.nextInt();
		

		

		if (rXSystem.registerBook(optionP, id, name, numPages, category, review, genre, url, price, peridiocity, subscriptions, ventas, readPages,diaInicio, mesInicio, anInicio)) {

			System.out.println("Libro registrado exitosamente");

		} else {

			System.out.println("Memoria llena, no se pudo registrar el libro");
		}
	}


	private void modifyProduct() {

		String query = rXSystem.getBookList();

		if (query.equals("")) {

			System.out.println("No hay productos registrados");
		} else {

			System.out.println("\nEste es el listado de productos registrados en el sistema");

			System.out.println(query);

			System.out.println("\nSeleccione el producto a editar");

			int option = reader.nextInt();

			String consult = rXSystem.getProductType(option-1);

			int option3 = 0;
			String modificacion = "";
			String fechaChange = "";

			if(consult.equals("L")){

				System.out.println("El producto es un libro, que desea modificar?");
				System.out.println("1. Id");
				System.out.println("2. Nombre");
				System.out.println("3. Numero de pagina");
				System.out.println("4. Precio");
				System.out.println("5. Fecha de publicacion");
				System.out.println("6. Reseña");
				System.out.println("7. Genero (Por favor escriba una de las siguientes en mayusculas CIENCIA FICCION, FANTASIA, NOVELA HISTORICA)");
				System.out.println("8. Url");

				option3 = reader.nextInt();

				if(option3 == 5){

					System.out.println("Por favor digita la fecha de publicación en dias, meses y año");

					System.out.println("Digite el dia de publicacion");
					int diaInicio = reader.nextInt();

					System.out.println("Digite el mes de publicacion");
					int mesInicio = reader.nextInt();

					System.out.println("Digite el año de publicacion");
					int anInicio = reader.nextInt();
		

					Calendar fechaProvisional = new GregorianCalendar(diaInicio, mesInicio-1, anInicio);

					SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
		
					fechaChange = formatoFecha.format(fechaProvisional.getTime());

					modificacion = fechaChange;

				}else{

					reader.nextLine();

					System.out.println("Digite el nuevo valor");
					modificacion = reader.nextLine();

				}


			}else if(consult.equals("R")){

				System.out.println("El producto es un libro, que desea modificar?");
				System.out.println("1. Id");
				System.out.println("2. Nombre");
				System.out.println("3. Numero de pagina");
				System.out.println("4. Fecha de publicacion");
				System.out.println("5. Precio");
				System.out.println("6. Categoria (Por favor escriba una de las siguientes en mayusculas VARIEDADES, DISEÑO, CIENTIFICA)");
				System.out.println("7. Url");
				System.out.println("8. Periodicidad");

				option3 = reader.nextInt();

				reader.nextLine();

				if(option3 == 4){

					System.out.println("Por favor digita la fecha de publicación en dias, meses y año");

					System.out.println("Digite el dia de publicacion");
					int diaInicio = reader.nextInt();

					System.out.println("Digite el mes de publicacion");
					int mesInicio = reader.nextInt();

					System.out.println("Digite el año de publicacion");
					int anInicio = reader.nextInt();
		

					Calendar fechaProvisional = new GregorianCalendar(diaInicio, mesInicio-1, anInicio);

					SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
		
					fechaChange = formatoFecha.format(fechaProvisional.getTime());

					modificacion = fechaChange;

				}else{

					reader.nextLine();

					System.out.println("Digite el nuevo valor");
					modificacion = reader.nextLine();

				}

				

			}

			if (rXSystem.editProduct(consult, option-1, modificacion, option3)) {

				System.out.println("\nProducto editado exitosamente");

			} else {

				System.out.println("\nError, el producto no pudo ser editado");
			}

		}

	}

	private void deleteProduct() {

		String query = rXSystem.getBookList();

		if (query.equals("")) {

			System.out.println("No hay productos registrados");
		} else {

			System.out.println("\nEste es el listado de usuarios registrados en el sistema");

			System.out.println(query);

			System.out.println("\nSeleccione el usuario a borrar");

			int option = reader.nextInt();

			System.out.println(rXSystem.deleteProduct(option - 1)); 

		}

	}

	private void sellBook() {

		String query1 = rXSystem.getUserList();

		if (query1.equals("")) {

			System.out.println("No hay usuarios registrados");
		} else {

			String query = rXSystem.getOnlyBookList();

			if (query.equals("")) {

				System.out.println("No hay libros registrados");

			} else {

			System.out.println("\nEste es el listado de usuarios");

			System.out.println(query1);

			System.out.println("\nSeleccione el usuario que desea comprar un libro");

			int option1 = reader.nextInt();

			System.out.println("\nEste es el listado de libros registrados en el sistema");

			System.out.println(query);

			System.out.println("\nSeleccione el producto a comprar");

			int option = reader.nextInt();

			String receipt = rXSystem.sellBook(option1-1, option - 1);

			if (receipt.equals("")) {

				System.out.println("\nError en la compra");

			} else {

				System.out.println(receipt);

				System.out.println("\nCompra realizada exitosamente");
			}

		}

		}
		

	}

	private void subscribeMagazine() {

		String query1 = rXSystem.getUserList();

		if (query1.equals("")) {

			System.out.println("No hay usuarios registrados");
		} else {

			String query = rXSystem.getOnlyRevistaList();

			if (query.equals("")) {

				System.out.println("No hay revistas registrados");

			} else {

				System.out.println("\nEste es el listado de usuarios");

				System.out.println(query1);

				System.out.println("\nSeleccione el usuario que desea comprar un producto");

				int option1 = reader.nextInt();

				System.out.println("\nEste es el listado de revistas registradas en el sistema");

				System.out.println(query);

				System.out.println("\nSeleccione el producto a vender");

				int option = reader.nextInt();

				String receipt = rXSystem.subscribeMagazine(option1-1, option - 1);

				if (receipt.equals("")) {

					System.out.println("\nError en la suscripcion");

				} else {

					System.out.println(receipt);

					System.out.println("\nSuscripcion realizada exitosamente");
				}

			}

		}
		

	}

	private void unsubscribeMagazine(){

		String query1 = rXSystem.getUserList();

		if (query1.equals("")) {

			System.out.println("No hay usuarios registrados");

		} else {
			
			System.out.println("\nEste es el listado de usuarios");

			System.out.println(query1);

			System.out.println("\nSeleccione el usuario que desea desuscribir de una revista");

			int option1 = reader.nextInt();

			String query = rXSystem.searchMagazines(option1-1);

			if (query.equals("")) {

				System.out.println("No hay revistas registrados");

			} else {

			
				System.out.println("\nEste es el listado de revistas a las que el usuario esta suscrito");

				System.out.println(query);

				System.out.println("\nSeleccione la revista de la cual desea desuscribirse");

				int option = reader.nextInt();


				if(rXSystem.unsuscribeMagazine(option1-1, option-1)) {

					System.out.println("\nDesuscripcion realizada exitosamente");

				} else {

					System.out.println("\nError al desuscribirse");
				}

			}

		}
	}

	private void simulateLecture(){

		String query1 = rXSystem.getUserList();

		if (query1.equals("")) {

			System.out.println("No hay usuarios registrados");
		} else {

			System.out.println("\nEste es el listado de usuarios");

			System.out.println(query1);

			System.out.println("\nSeleccione el usuario que desea simular la lectura de un producto");

			int option1 = reader.nextInt();

			String query = rXSystem.searchProducts(option1-1);

			if (query.equals("")) {

				System.out.println("No hay productos registrados");

			} else {

				int salir = 1;

				while(salir == 1){

					System.out.println("\nEste es el listado de productos del usuario");

					System.out.println(query);

					System.out.println("\n Que tipo de producto quiere leer? 1)Libro 2)Revista");
					
					int option3 = reader.nextInt();

					String query2 = "";

					if(option3 == 1){

						query2 = rXSystem.searchBooks(option1-1);

					}else{

						query2 = rXSystem.searchMagazines(option1-1);

					}

					System.out.println("\n" + query2);
					
					System.out.println("\nSeleccione el producto a leer");

					int option = reader.nextInt();

					int tipoUser = rXSystem.tipoUser(option1-1);

					String name = rXSystem.productName(option1-1, option-1, option3);
					
					int letter = 1; 
					
					int contador = 1;

					int posicion = rXSystem.compareProduct(name);

					while(letter == 1 || letter == 2){

						if(tipoUser == 1){
							int num = contador % 20;
							if(num == 0){

								int valor = rXSystem.Random();

								if(valor == 1){

									System.out.println("¡Estamos de aniversario! Visita tu Éxito más cercano y sorpréndete con las mejores ofertas!");

								}else if(valor == 2){

									System.out.println("Ahora tus mascotas tienen una app favorita: Laika. Los mejores productos para tu peludito.");

								}else if(valor == 3){

									System.out.println("¡Suscríbete al Combo Plus y llévate Disney+ y Star+ a un precio increíble!");

								}

							}else{

								System.out.println(rXSystem.simulateLecture(option3, contador, posicion, name));

							}

							letter = reader.nextInt();
							

						}else if(tipoUser == 2){

							System.out.println(rXSystem.simulateLecture(option3, contador, posicion, name));

							letter = reader.nextInt();

						}

						int valor = 0;

						if(letter == 1){

							contador = contador + 1;
							valor = rXSystem.getPagesProduct(posicion);
							if(contador > valor){
								contador = 1;
							}

						}else if(letter == 2){

							contador = contador - 1;
							if(contador < 1){
								valor = rXSystem.getPagesProduct(posicion);
								contador = valor;

							}

						}

						

					}

					System.out.println("Desea leer otro libro? 1) Si 2)No");
					salir = reader.nextInt();
				}
				


			}

		}

	}

	private void showMatrix(){

		String query1 = rXSystem.getUserList();

		if (query1.equals("")) {

			System.out.println("No hay usuarios registrados");
		} else {

			System.out.println("\nEste es el listado de usuarios");

			System.out.println(query1);

			System.out.println("\nSeleccione el usuario para mostrar su biblioteca");

			int option1 = reader.nextInt();

			System.out.println(rXSystem.showMatrix(option1-1));
		}


		 

	}

	private void totalPages(){

		System.out.println("El acumulado de paginas leidas por producto es: ");

		System.out.println(rXSystem.totalPagesProduct()); 

	}

	private void genCatMRead(){

		System.out.println("El género de libro y categoría de revista más leídas registrado hasta ahora");

		System.out.println(rXSystem.genCatMRead());
	}

	private void topRead(){

	}

	private void bookSales(){

		System.out.println("El número de libros vendidos y el valor total de ventas por genero");

		System.out.println(rXSystem.bookSales());

	}

	private void magazineSuscriptions(){

		System.out.println("El número de suscripciones a revistas y el valor total pagado por suscripcione de cada categoria");

		System.out.println(rXSystem.magazineSuscriptions());

	}



}