package model;

import java.util.Date;
import java.util.Random;
import java.util.ArrayList;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;

public class Controller {

	private ArrayList<Product> products;
	private ArrayList<User> users;

	public Controller() {

		this.users = new ArrayList<User>();
		this.products = new ArrayList<Product>();
		testCases();

	}

	public void testCases() {

		users.add(new Regular("1234", "John Smith", "Smithy", "04/03/2021"));
		users.add(new Regular("5678", "Pocahontas", "Pocah", "05/02/2022"));
		users.add(new Premium("3124", "Pepe Cuartas", "PCuartas", "06/01/2022"));
		products.add(new Libro("4AF", "A Game of Thrones", 694, 19.19,"01/08/1996","Join adventurers across the seven kingdoms", Genre.FANTASIA, "AGOT.png", 12314, 141241234.0));
		products.add(new Revista("4AZ", "Vogue", 40,"01/08/1996",4, RevistaCat.VARIEDADES, "LMV2021.jpg","Mensual", 122867, 7531341.0));
		products.add(new Libro("3BD ", "Santa Biblia", 500,20.02,"02/09/1500", "Jesus se encuentra peliando con el presidente de EE.UU con el poder de la rotación", Genre.FANTASIA,"BibliaJN.jpg", 122867, 7531341.0));
	}

	public String getUserList() {

		String msg = "";

		for (int i = 0; i < users.size(); i++) {

				msg += "\n" + (i + 1) + ". " + users.get(i).getId() + " - " + users.get(i).getName();

		}

		return msg;

	}

	public String registerUser(String id, String name, String nickname, int option) {

		Date fechaActual = new Date();
		
		SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
		
		String fechaChange = formatoFecha.format(fechaActual);


                if(option == 1){
                    users.add(new Regular(id, name, nickname, fechaChange));
                    return "Se ha registrado el usuario Regular";
                }
                else if(option == 2){
                    users.add(new Premium(id, name, nickname, fechaChange));
                    return "Se ha registrado el usuario Premium";
           		}

		return "No se ha podido registrar el usuario";
	}

	public boolean editProduct(String consult, int posicionproducto,  String modificacion, int atributo) {

		if(consult.equals("L")){

			switch(atributo){

				case 1:
					products.get(posicionproducto).setId(modificacion);
					return true;
				case 2:
					products.get(posicionproducto).setName(modificacion);
					return true;
				case 3:
					int valorE = Integer.parseInt(modificacion);
					products.get(posicionproducto).setNumPages(valorE);
					return true;
				case 4:
					double price1 = Double.parseDouble(modificacion);
					products.get(posicionproducto).setPrice(price1);
					return true;
				case 5:
					products.get(posicionproducto).setPublicationDate(modificacion);
					return true;
				case 6:
					((Libro)(products.get(posicionproducto))).setReview(modificacion);
					return true;
				case 7:
					
					Genre genre1 = null;
					switch (modificacion) {
					case "CIENCIA FICCION":
						genre1 = Genre.CIENCIAFICCION;
						break;
					case "FANTASIA":
						genre1 = Genre.FANTASIA;
						break;
					case "NOVELA HISTORICA":
						genre1 = Genre.NOVELAHISTORICA;
						break;
					}

					((Libro)(products.get(posicionproducto))).setGenre(genre1);
					return true;
				case 8:
					products.get(posicionproducto).setUrl(modificacion);
					return true;
	
			}

		}
		if(consult.equals("R")){

			switch(atributo){

				case 1:
					products.get(posicionproducto).setId(modificacion);
					return true;
				case 2:
					products.get(posicionproducto).setName(modificacion);
					return true;
				case 3:
					int valorE = Integer.parseInt(modificacion);
					products.get(posicionproducto).setNumPages(valorE);
					return true;
				case 4:
					products.get(posicionproducto).setPublicationDate(modificacion);
					return true;
				case 5:
					double price1 = Double.parseDouble(modificacion);
					products.get(posicionproducto).setPrice(price1);
					return true;
				case 6:

					RevistaCat revistaCat = null;
					switch (modificacion) {
					case "VARIEDADES":
						revistaCat = RevistaCat.VARIEDADES;
						break;
					case "DISEÑO":
						revistaCat = RevistaCat.DISEÑO;
						break;
					case "CIENTIFICA":
						revistaCat = RevistaCat.CIENTIFICA;
						break;
					}
					((Revista)(products.get(posicionproducto))).setCategory(revistaCat);
					return true;
				case 7: 
					products.get(posicionproducto).setUrl(modificacion);
					return true;
				case 8:
					((Revista)(products.get(posicionproducto))).setPeridiocity(modificacion);
					return true;
	
				
			}

		}
	

        return false;
    }
	

	public String deleteProduct(int productPosition) {

		String msg = "";

		products.remove(productPosition);

		msg = "Usuario borrado exitosamente";

		return msg;
	}

	public String getUserInfo(int option) {

		String msg = "";

		msg += "\nId: " + users.get(option).getId() + "\nName: " + users.get(option).getName() + "\nNickname: " + users.get(option).getNickname() + "\nSign Up Date: " + users.get(option).getSignUpDate();

		return msg;
	}

	public String getAllUserInfo() {

		String msg = "";

		int premiumUsers = 0;
		int regularUsers = 0;

		for(int i = 0 ; i< users.size(); i++){

            if(users.get(i) instanceof Regular){
				regularUsers += 1;
			}

			if(users.get(i) instanceof Premium){

				premiumUsers += 1;
			}
        }

		msg += "Cantidad de usuarios regular: " + regularUsers 
		+ "\nCantidad de usuarios premium: " + premiumUsers;

		return msg;
	}

	public String getUserType(int option) {

		String msg = "";

                if(users.get(option) instanceof Regular){
                    msg+="R";
                }

                if(users.get(option) instanceof Premium){
                    msg+="P";
                }

		return msg;

	}

	public String getProductType(int option) {

		String msg = "";

                if(products.get(option) instanceof Libro){
                    msg+="L";
                }

                if(products.get(option) instanceof Revista){
                    msg+="R";
                }

		return msg;

	}

	public boolean registerBook(int optionP, String id, String name, int numPages, int category, String review, int genre, String url, double price, String periodicity, int subscriptions, int ventas, double readPages, int diaInicio, int mesInicio, int anInicio ) {

		

		Calendar fechaProvisional = new GregorianCalendar(diaInicio, mesInicio-1, anInicio);

		SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
		
		String fechaChange = formatoFecha.format(fechaProvisional.getTime());


		Genre genreType = Genre.CIENCIAFICCION;

        if (genre == 1){

            genreType = Genre.CIENCIAFICCION;

        }else if (genre == 2){

            genreType = Genre.FANTASIA;

        }else{

			genreType = Genre.NOVELAHISTORICA;

		}

		RevistaCat cat = RevistaCat.CIENTIFICA;

		if (category == 1){

			cat = RevistaCat.VARIEDADES;

		}else if (category == 2){

			cat = RevistaCat.DISEÑO;

		}else{

			cat = RevistaCat.CIENTIFICA;

		}

			if(optionP == 1){
				products.add(new Libro(id, name, numPages, price, fechaChange, review, genreType, url, ventas, readPages));
				return true;
			}else if(optionP == 2){
				products.add(new Revista(id, name, numPages, fechaChange, price, cat, url, periodicity, subscriptions, readPages));
				return true;
			}
		
		return false;
    
	}

	public String getBookList() {

		String msg = "";

		for (int i = 0; i < products.size(); i++) {

				msg += "\n" + (i + 1) + ". " + products.get(i).getName() + " - " + products.get(i).getPrice();

		}
		
		return msg;

	}

	public String getOnlyBookList() {

		String msg = "";

		for (int i = 0; i < products.size(); i++) {

			if(products.get(i) instanceof Libro){

				msg += "\n" + (i + 1) + ". " + products.get(i).getName() + " - " + products.get(i).getPrice();

			}
		}
		
		return msg;

	}

	public String getOnlyRevistaList() {

		String msg = "";

		for (int i = 0; i < products.size(); i++) {

			if(products.get(i) instanceof Revista){

				msg += "\n" + (i + 1) + ". " + products.get(i).getName() + " - " + products.get(i).getPrice();
				
			}
		}
		
		return msg;

	}


	public String sellBook(int t, int i) {

		String msg = "";

		Calendar fechaActual = new GregorianCalendar();

		double precio = products.get(i).getPrice();

		String name = products.get(i).getName();

		int valor = (((Libro)(products.get(i))).getUnitsSold()) + 1;

		((Libro)(products.get(i))).setUnitsSold(valor);

		String id = products.get(i).getId();
		String name1 = products.get(i).getName();
		int numPages = products.get(i).getNumPages();
		Double price = products.get(i).getPrice();
		String publicationDate = products.get(i).getPublicationDate();
		String review = ((Libro)(products.get(i))).getReview();
		Genre genre = ((Libro)(products.get(i))).getGenre();
		String url = products.get(i).getUrl();
		Double readPages = products.get(i).getReadPages();
		int unitsSold = ((Libro)(products.get(i))).getUnitsSold();

		if(users.get(t) instanceof Premium){

			((Premium)(users.get(t))).buyBooks(id, name1, numPages, price, publicationDate, review, genre, url, readPages, unitsSold);

		}
		if(users.get(t) instanceof Regular){

			((Regular)(users.get(t))).buyBooks(id, name1, numPages, price, publicationDate, review, genre, url, readPages, unitsSold);

		}
		

		msg += "\nEste es su recibo" + "\nFecha de compra: " + fechaActual + "\nPrecio de la compra: " + precio + "\nLibro comprado: " + name;

		return msg;
	}

	public String subscribeMagazine(int t, int i) {

		String msg = "";

		Calendar fechaActual = new GregorianCalendar();

		double precio = products.get(i).getPrice();

		String name = products.get(i).getName();

		int valor = (((Revista)(products.get(i))).getSubscriptions()) + 1;

		((Revista)(products.get(i))).setSubscriptions(valor);

		String id = products.get(i).getId();
		String name1 = products.get(i).getName();
		int numPages = products.get(i).getNumPages();
		Double price = products.get(i).getPrice();
		String publicationDate = products.get(i).getPublicationDate();
		String url = products.get(i).getUrl();
		RevistaCat revistaCat = ((Revista)(products.get(i))).getCategory();
		String peridiocity = ((Revista)(products.get(i))).getPeridiocity();
		Double readPages = products.get(i).getReadPages();
		int subscriptions = ((Revista)(products.get(i))).getSubscriptions();


		if(users.get(t) instanceof Premium){

			((Premium)(users.get(t))).subscribeMagazine(id, name1, numPages, price, publicationDate, url, revistaCat, peridiocity, readPages, subscriptions);

		}
		if(users.get(t) instanceof Regular){

			((Regular)(users.get(t))).subscribeMagazine(id, name1, numPages, price, publicationDate, url, revistaCat, peridiocity, readPages, subscriptions);

		}
		

		msg += "\nEste es su recibo" + "\nFecha de compra: " + fechaActual + "\nPrecio de la compra: " + precio + "\nSuscribción a revista: " + name;

		return msg;
	}


	public String[][] fillMatrix(int usuario){

		String[][] matrix1 = new String[5][5];

		if(users.get(usuario) instanceof Premium){

			matrix1 = ((Premium)(users.get(usuario))).fillMatrix(usuario);

		}
		if(users.get(usuario) instanceof Regular){

			matrix1 = ((Regular)(users.get(usuario))).fillMatrix(usuario);

		}

		return matrix1;

	}

	public String showMatrix(int usuario) {

		String[][] matrix = fillMatrix(usuario);

	
		String print = "";
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < matrix[0].length; j++) {

				if (matrix[i][j] == null) {

					print += "___" + " ";
				} else {
					print += matrix[i][j] + " ";
				}

			}
			print += "\n";
		}

		return print;
	}



	public String getAllKBookInfo() {

		String msg = "";
		
		double ventasTotales = 0;

		for (int i = 0; i < products.size(); i++) {
				
				//obtener las ventas totales del libro
				if(products.get(i) instanceof Revista){

					ventasTotales = (products.get(i).getPrice())*((Revista)(products.get(i))).getSubscriptions();

					msg += "\n" + (i + 1) + ". " + products.get(i).getBookInfo() + "Ganancias por suscripciones totales: " + ventasTotales;

				}

				if(products.get(i) instanceof Libro){

					ventasTotales = (products.get(i).getPrice())*((Libro)(products.get(i))).getUnitsSold();

					msg += "\n" + (i + 1) + ". " + products.get(i).getBookInfo() + "Ventas totales: " + ventasTotales;

				}
				

		}

		return msg;
	}

	public boolean unsuscribeMagazine(int option1, int option){


		if(users.get(option1) instanceof Regular){
			((Regular)(users.get(option1))).unsuscribe(option);
		}

		if(users.get(option1) instanceof Premium){
			((Premium)(users.get(option1))).unsuscribe(option);
		}

		return true;

	}

	public String searchProducts(int option){

		String msg = "";

		if(users.get(option) instanceof Regular){
			msg += ((Regular)(users.get(option))).getProductInfo();
		}

		if(users.get(option) instanceof Premium){
			msg += ((Premium)(users.get(option))).getProductInfo();
		}

		return msg;
	}

	public String searchBooks(int option){

		String msg = "";

		if(users.get(option) instanceof Regular){
			msg += ((Regular)(users.get(option))).getBooks();
		}

		if(users.get(option) instanceof Premium){
			msg += ((Premium)(users.get(option))).getBooks();
		}

		return msg;
	}

	public String searchMagazines(int option){

		String msg = "";

		if(users.get(option) instanceof Regular){
			msg += ((Regular)(users.get(option))).getMagazines();
		}

		if(users.get(option) instanceof Premium){
			msg += ((Premium)(users.get(option))).getMagazines();
		}

		return msg;
	}

	public String productName(int usuario, int producto, int tipo){

		String msg = "";
		int option = 0;

		if(users.get(usuario) instanceof Regular){
			option = 1;
		}

		if(users.get(usuario) instanceof Premium){
			option = 2;
		}

		if(tipo == 1){

			if(option == 1){

				msg += ((Regular)(users.get(usuario))).getNameBook(producto);

			}else if(option == 2){
				
				msg += ((Premium)(users.get(usuario))).getNameBook(producto);

			}

		}else if(tipo == 2){

			if(option == 1){

				msg += ((Regular)(users.get(usuario))).getNameMagazine(producto);

			}else if(option == 2){

				msg += ((Premium)(users.get(usuario))).getNameMagazine(producto);
				
			}

		}

		return msg;
	}
	
	public int tipoUser(int usuario){

		int option = 0;

		if(users.get(usuario) instanceof Regular){
			option = 1;
		}

		if(users.get(usuario) instanceof Premium){
			option = 2;
		}

		return option;

	}

	public String simulateLecture(int option3, int contador, int posicion, String name){

		String msg = "";

		int pages = products.get(posicion).getNumPages();
		
		if(option3 == 1){

			msg += ((Libro)(products.get(posicion))).readProduct(contador, pages, name);
			
		}else if(option3 == 2){

			msg += ((Revista)(products.get(posicion))).readProduct(contador, pages, name);
			
		}

		return msg;

	}

	public int getPagesProduct(int posicion){

		int pages = products.get(posicion).getNumPages();

		return pages;

	}

	
	public int Random() {

			Random random = new Random();
			int randomNumber = random.nextInt(3) + 1;
			
			return randomNumber;
	}
	

	public int compareProduct(String name){

		int option = 0;

		for (int i = 0; i < products.size(); i++) {

			if(name.equals(products.get(i).getName())){

				return i;

			}
		}
		
		return option;

	}
	
	public String totalPagesProduct(){

		String msg = "";
		double paginasLibro = 0;
		double paginasRevista = 0;

		for (int i = 0; i < products.size(); i++) {

			if(products.get(i) instanceof Libro){
				paginasLibro = paginasLibro + products.get(i).getReadPages();
			}
	
			if(products.get(i) instanceof Revista){
				paginasRevista = paginasRevista + products.get(i).getReadPages();
			}
		}

		msg += "Las paginas totales leidas de libros es: " + paginasLibro + 
		"\n" + "Las paginas totales leidas de revistas es: " + paginasRevista;

		return msg;

	}

	public String genCatMRead(){

		String msg = "";
		double libroCF = 0;
		double libroF = 0;
		double libroNH = 0;
		double revistaC = 0;
		double revistaD = 0;
		double revistaV = 0;
		Genre generoML = Genre.CIENCIAFICCION;
		RevistaCat catML = RevistaCat.CIENTIFICA;
		double paginasMax = 0;
		double paginasMax1 = 0;
	


		for (int i = 0; i < products.size(); i++) {

			if(products.get(i) instanceof Libro){

				Genre temp = ((Libro)(products.get(i))).getGenre();

				if(temp == Genre.CIENCIAFICCION){
					
					libroCF = libroCF + products.get(i).getReadPages();

				}else if(temp == Genre.FANTASIA){

					libroF = libroF + products.get(i).getReadPages();

				}else if(temp == Genre.NOVELAHISTORICA){

					libroNH = libroNH + products.get(i).getReadPages();

				}

			}
	
			if(products.get(i) instanceof Revista){

				RevistaCat temp1 = ((Revista)(products.get(i))).getCategory();
				
				if(temp1 == RevistaCat.CIENTIFICA){

					revistaC = revistaC + products.get(i).getReadPages();

				}else if(temp1 == RevistaCat.DISEÑO){

					revistaD = revistaD + products.get(i).getReadPages();

				}else if(temp1 == RevistaCat.VARIEDADES){

					revistaV = revistaV + products.get(i).getReadPages();

				}
			}
		}

		if(libroCF > libroF && libroCF > libroNH){

			generoML = Genre.CIENCIAFICCION;
			paginasMax = libroCF;

		}else if(libroF > libroCF && libroF > libroNH){

			generoML = Genre.FANTASIA;
			paginasMax = libroCF;
			
		}else if(libroNH > libroCF && libroNH > libroF){

			generoML = Genre.NOVELAHISTORICA;
			paginasMax = libroCF;
			
		}

		if(revistaC > revistaD && revistaC > revistaV){

			catML = RevistaCat.CIENTIFICA;
			paginasMax1 = libroCF;

		}else if(revistaD > revistaC && revistaD > revistaV){

			catML = RevistaCat.DISEÑO;
			paginasMax1 = libroCF;
			
		}else if(revistaV > revistaC && revistaV > revistaD){

			catML = RevistaCat.VARIEDADES;
			paginasMax1 = libroCF;
			
		}
		

		msg += "El genero mas leido de libros es: " + generoML + " con " + paginasMax + " leidas" +
		"\n" + "La categoria mas leida de revistas es: " + catML + " con " + paginasMax1 + " leidas";

		return msg;

	}

	public String bookSales(){

		String msg = "";
		double libroCF = 0;
		double valorCF = 0;
		double libroF = 0;
		double valorF = 0;
		double libroNH = 0;
		double valorNH = 0;

		for (int i = 0; i < products.size(); i++) {

			if(products.get(i) instanceof Libro){

				Genre temp = ((Libro)(products.get(i))).getGenre();

				if(temp == Genre.CIENCIAFICCION){
					
					libroCF = libroCF + 1; 
					valorCF += ((Libro)(products.get(i))).getUnitsSold() * products.get(i).getPrice();

				}else if(temp == Genre.FANTASIA){

					libroF = libroF + 1;
					valorF += ((Libro)(products.get(i))).getUnitsSold() * products.get(i).getPrice();

				}else if(temp == Genre.NOVELAHISTORICA){

					libroNH = libroNH + 1;
					valorNH += ((Libro)(products.get(i))).getUnitsSold() * products.get(i).getPrice();

				}

			}
		}

		msg += "Unidades vendidas de Ciencia Ficcion: " + libroCF + " ventas realizadas: " + valorCF +
		"\n" + "Unidades vendidas Fantasia: " + libroF + " ventas realizadas: " + valorF +
		"\n" + "Unidades vendidas Novela Historica: " + libroNH + " ventas realizadas: " + valorNH;

		return msg;
	}

	public String magazineSuscriptions(){

		String msg = "";
		double revistaCI = 0;
		double revistaD = 0;
		double revistaV = 0;
		double valorC = 0;
		double valorD = 0;
		double valorV= 0;

		for (int i = 0; i < products.size(); i++) {

			if(products.get(i) instanceof Libro){

				RevistaCat temp = ((Revista)(products.get(i))).getCategory();

				if(temp == RevistaCat.CIENTIFICA){
					
					revistaCI += 1; 
					valorC += ((Revista)(products.get(i))).getSubscriptions() * products.get(i).getPrice();

				}else if(temp == RevistaCat.DISEÑO){

					revistaD += 1;
					valorD += ((Revista)(products.get(i))).getSubscriptions() * products.get(i).getPrice();

				}else if(temp == RevistaCat.VARIEDADES){

					revistaV += 1;
					valorV += ((Revista)(products.get(i))).getSubscriptions() * products.get(i).getPrice();

				}

			}
		}

		msg += "Suscripciones a Cientifica: " + revistaCI + " ventas realizadas: " + valorC +
		"\n" + "Suscripciones a Diseño: " + revistaD + " ventas realizadas: " + valorD +
		"\n" + "Suscripciones a Variedades: " + revistaV + " ventas realizadas: " + valorV;

		return msg;

	}


	public boolean validaIdentificador(String id){        
		boolean valido = true;
		if(!id.substring(0, 1).matches("[A-F]*")){
			valido = false;
		}
		if(!id.substring(1, 2).matches("[0-9]*")){
			valido = false;
		}
		if(!id.substring(2, 3).matches("[A-F]*")){
			valido = false;
		}
		return valido;
	 }

	 public boolean validaIdentificador2(String id){        
		boolean valido = true;
		if(!id.substring(0, 1).matches("[A-Z]*")){
			valido = false;
		}
		if(!id.substring(1, 2).matches("[0-9]*")){
			valido = false;
		}
		if(!id.substring(2, 3).matches("[A-Z]*")){
			valido = false;
		}
		return valido;
	 }

}
