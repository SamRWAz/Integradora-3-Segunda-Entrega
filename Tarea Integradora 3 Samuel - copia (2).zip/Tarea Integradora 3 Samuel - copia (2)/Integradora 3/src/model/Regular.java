package model;

public class Regular extends User {

    private Libro[] libros;
    private Revista[] revistas;


    public Regular(String id, String name, String nickname, String signUpDate) {
        super(id, name, nickname, signUpDate);

       libros = new Libro[5];
       revistas = new Revista[2];

    }

    public boolean buyBooks(String id, String name1, int numPages, double price, String publicationDate, String review, Genre genre, String url, Double readPages, int unitsSold){

        for(int j = 0; j < libros.length; j++){
                
            if(libros[j] == null){
                libros[j] = new Libro(id, name1, numPages, price, publicationDate, review, genre, url, unitsSold, readPages);
                return true;  
            }
                
        }
        
        return false;

    }

    public boolean subscribeMagazine(String id, String name1, int numPages, double price, String publicationDate, String url, RevistaCat category, String peridiocity, Double readPages, int subscription){

        for(int j = 0; j < revistas.length; j++){
  
            if(revistas[j] == null){
                revistas[j] = new Revista(id, name1, numPages, publicationDate, price, category, url, peridiocity, subscription, readPages);
                return true;
            }
        }
        
        return false;
    }

    public String getProductInfo(){

        String msg = "";

        msg += "Libros registrados:"+ "\n";

        for(int i = 0; i < libros.length; i++){

            if(libros[i]!=null){

                msg += (i+1) + "." + libros[i].getId() + " - " + libros[i].getName() + "\n";

            }

        }

        msg += "Revistas registradas: " + "\n";

        for(int i = 0; i < revistas.length; i++){

            if(revistas[i]!=null){

                msg += (i+1) + "." + revistas[i].getId() + " - " + revistas[i].getName() + "\n";

            }

        }
        

        return msg;

    }

    public String getBooks(){

        String msg = "";

        for(int i = 0; i < libros.length; i++){

            if(libros[i]!=null){

                msg += (i+1) + "." + libros[i].getId() + " - " + libros[i].getName() + "\n";

            }

        }
        

        return msg;

    }

    public String getMagazines(){

        String msg = "";

        for(int i = 0; i < revistas.length; i++){

            if(revistas[i]!=null){

                msg += (i+1) + "." + revistas[i].getId() + " - " + revistas[i].getName() + "\n";

            }

        }

        return msg;

    }

    public int getPagesBook(int producto){

        int pages = 0;

        pages = libros[producto].getNumPages();

        return pages;

    }

    public int getPagesMagazine(int producto){

        int pages = 0;

        pages = revistas[producto].getNumPages();

        return pages;

    }

    public String getNameBook(int producto){

        String msg = "";

        msg += libros[producto].getName();

        return msg;

    }

    public String getNameMagazine(int producto){

        String msg = "";

        msg += revistas[producto].getName();

        return msg;

    }

    public String[][] fillMatrix(int usuario) {

		String[][] matrix = new String[5][5];
		for (int contador = 0; contador < libros.length; contador++){
			boolean termino = false;
			for (int i = 0; i < matrix.length && !termino; i++) {

				boolean termino1 = false;
				for (int j = 0; j < matrix[0].length && !termino1; j++) {

					if(matrix[i][j] == null){
                        if(libros[contador]!=null){
                            matrix[i][j]  = libros[contador].getId();
                        }
						
							
						termino = true;
						termino1 = true;
						

					}
				}
			}
		}

        for (int contador = 0; contador < revistas.length; contador++){
			boolean termino = false;
			for (int i = 0; i < matrix.length && !termino; i++) {

				boolean termino1 = false;
				for (int j = 0; j < matrix[0].length && !termino1; j++) {

					if(matrix[i][j] == null){
                        
                        if(revistas[contador]!=null){
                            matrix[i][j]  = revistas[contador].getId();
                        }
							
						termino = true;
						termino1 = true;
						

					}
				}
			}
		}

		return matrix;

	}

    public void unsuscribe(int option) {

        revistas[option] = null;

    }
    
}

