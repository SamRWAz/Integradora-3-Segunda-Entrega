package model;

public enum Genre {

    CIENCIAFICCION, FANTASIA, NOVELAHISTORICA;
    
}

