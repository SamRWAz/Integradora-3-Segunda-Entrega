package model;

public enum Category {

    PLATA,ORO,DIAMANTE;
    
}
