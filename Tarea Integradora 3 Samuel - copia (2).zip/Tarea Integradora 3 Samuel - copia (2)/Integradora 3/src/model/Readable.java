package model;

public interface Readable {

    public String readProduct(int contador, int pages, String name);
    
}
