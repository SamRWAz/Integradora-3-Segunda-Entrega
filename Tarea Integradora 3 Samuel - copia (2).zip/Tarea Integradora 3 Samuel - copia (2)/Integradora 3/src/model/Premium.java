package model;

import java.util.ArrayList;

public class Premium extends User {

    private ArrayList<Libro> libros;
	private ArrayList<Revista> revistas;

    public Premium(String id, String name, String nickname, String signUpDate) {
        super(id, name, nickname, signUpDate);

        this.libros = new ArrayList<Libro>();
		this.revistas = new ArrayList<Revista>();
    }

    public boolean buyBooks(String id, String name1, int numPages, double price, String publicationDate, String review, Genre genre, String url, Double readPages, int unitsSold){
         
        libros.add(new Libro(id, name1, numPages, price, publicationDate, review, genre, url, unitsSold, readPages));
        return true;               

    }

    public boolean subscribeMagazine(String id, String name1, int numPages, double price, String publicationDate, String url, RevistaCat category, String peridiocity, Double readPages, int subscription){

        revistas.add(new Revista(id, name1, numPages, publicationDate, price, category, url, peridiocity, subscription, readPages));
        return true;

    }


    public String getProductInfo(){

        String msg = "";

        msg += "Libros registrados: " + "\n";

        for(int i = 0; i < libros.size(); i++){

            msg += (i+1) + "." + libros.get(i).getId() + " - " + libros.get(i).getName() + "\n";

        }

        msg += "Revistas registradas: " + "\n";

        for(int i = 0; i < revistas.size(); i++){

            msg += (i+1) + "." + revistas.get(i).getId() + " - " + revistas.get(i).getName() + "\n";

        }
        

        return msg;

    }

    public String getBooks(){

        String msg = "";

        for(int i = 0; i < libros.size(); i++){

            msg += (i+1) + "." + libros.get(i).getId() + " - " + libros.get(i).getName() + "\n";

        }
        

        return msg;

    }

    public String getMagazines(){

        String msg = "";

        for(int i = 0; i < revistas.size(); i++){

            msg += (i+1) + "." + revistas.get(i).getId() + " - " + revistas.get(i).getName() + "\n";

        }

        return msg;

    }

    public int getPagesBook(int producto){

        int pages = 0;

        pages = libros.get(producto).getNumPages();

        return pages;

    }

    public int getPagesMagazine(int producto){

        int pages = 0;

        pages = revistas.get(producto).getNumPages();

        return pages;

    }

    public String getNameBook(int producto){

        String msg = "";

        msg += libros.get(producto).getName();

        return msg;

    }

    public String getNameMagazine(int producto){

        String msg = "";

        msg += revistas.get(producto).getName();

        return msg;

    }

    public String[][] fillMatrix(int usuario) {

		String[][] matrix = new String[5][5];
		for (int contador = 0; contador < libros.size(); contador++){
			boolean termino = false;
			for (int i = 0; i < matrix.length && !termino; i++) {

				boolean termino1 = false;
				for (int j = 0; j < matrix[0].length && !termino1; j++) {

					if(matrix[i][j] == null){

						matrix[i][j]  = libros.get(contador).getId();
							
						termino = true;
						termino1 = true;
						

					}
				}
			}
		}

        for (int contador = 0; contador < revistas.size(); contador++){
			boolean termino = false;
			for (int i = 0; i < matrix.length && !termino; i++) {

				boolean termino1 = false;
				for (int j = 0; j < matrix[0].length && !termino1; j++) {

					if(matrix[i][j] == null){

						matrix[i][j]  = revistas.get(contador).getId();
							
						termino = true;
						termino1 = true;
						

					}
				}
			}
		}

		return matrix;

	}

    public void unsuscribe(int option) {

        revistas.remove(option);
        
    }

    
}
