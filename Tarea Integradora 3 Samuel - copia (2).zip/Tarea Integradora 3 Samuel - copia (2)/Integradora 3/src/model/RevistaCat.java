package model;

public enum RevistaCat {

    VARIEDADES, DISEÑO, CIENTIFICA;
    
}
